<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Update',
	'checkUpdate' => 'Check for Updates',

	'upToDateTitle' => 'Up-To-Date',
	'upToDate' => 'Cesium Template is up-to-date.',

	'updateAvailableTitle' => 'Update Available!',
	'updateAvailable' => 'Update for Cesium Template is available.',

	'updateNow' => 'Update Now',

	'currentVersion' => 'Current Version',
	'latestVersion' => 'Latest Version',
	'changelogs' => 'Changelogs',

	'unknownVersion' => 'Your Cesium Template version is unknown',
	'unknownError' => 'An error error has occured. Please try again later.',

);