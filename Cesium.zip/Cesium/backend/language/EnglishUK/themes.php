<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Themes',
	'new' => 'New Theme',
	'edit' => 'Edit Theme',
	'import' => 'Import Theme',

	'name' => 'Theme Name',
	'author' => 'Theme Author',

	'basic' => 'Basic Settings',
	'colors' => 'Colors',
	'advancedColors' => 'Advanced Colors',
	'advancedProperties' => 'Advanced Properties',
	'customCSS' => 'Custom CSS',

	'enableBorders' => 'Enable Borders',
	'enableRounded' => 'Enable Rounded Corners',
	'enableShadows' => 'Enable Box Shadows',

	'avatarsStyle' => 'Avatars Style',
	'avatarsDefault' => 'Default Avatars',
	'avatarsRounded' => 'Rounded Avatars',
	'avatarsCircle' => 'Circle Avatars',

	'defaultColor' => 'Default Color',
	'primaryColor' => 'Primary Color',
	'secondaryColor' => 'Secondary Color',
	'successColor' => 'Success Color',
	'dangerColor' => 'Danger Color',
	'infoColor' => 'Info Color',
	'warningColor' => 'Warning Color',

	'light' => 'Light',
	'dark' => 'Dark',

	'pageBackground' => 'Page Background',
	'primaryBackground' => 'Primary Background',
	'secondaryBackground' => 'Secondary Background',

	'primaryText' => 'Primary Text',
	'secondaryText' => 'Secondary Text',
	'mutedText' => 'Muted Text',

	'whiteColor' => 'White Color',
	'gray100Color' => 'Gray-100 Color',
	'gray200Color' => 'Gray-200 Color',
	'gray300Color' => 'Gray-300 Color',
	'gray400Color' => 'Gray-400 Color',
	'gray500Color' => 'Gray-500 Color',
	'gray600Color' => 'Gray-600 Color',
	'gray700Color' => 'Gray-700 Color',
	'gray800Color' => 'Gray-800 Color',
	'gray900Color' => 'Gray-900 Color',
	'blackColor' => 'Black Color',

	'fontFamily' => 'Font Family',
	'fontURL' => 'Font URL',
	'fontSize' => 'Font Size',
	'fontWeight' => 'Font Weight',
	
	'weightRegular' => 'Regular Font Weight',
	'weightMedium' => 'Medium Font Weight',
	'weightBold' => 'Bold Font Weight',
	
	'metaColor' => 'Meta Color',
	'metaSize' => 'Meta Size',
	'metaWeight' => 'Meta Weight',

	'hrColor' => 'Hr Color',
	'hrHeight' => 'Hr Height',
	'hrSpacing' => 'Hr Spacing',

	'borderSM' => 'Small Border',
	'border' => 'Medium Border',
	'borderLG' => 'Large Border',

	'borderRadiusSM' => 'Small Border Radius',
	'borderRadius' => 'Medium Border Radius',
	'borderRadiusLG' => 'Large Border Radius',

	'boxShadowSM' => 'Small Box Shadow',
	'boxShadow' => 'Medium Box Shadow',
	'boxShadowLG' => 'Large Box Shadow',

	'spacingSM' => 'Small Spacing',
	'spacing' => 'Medium Spacing',
	'spacingLG' => 'Large Spacing',

	'paddingSM' => 'Small Padding',
	'padding' => 'Medium Padding',
	'paddingLG' => 'Large Padding',

	'buttonPaddingSM' => 'Small Button Padding',
	'buttonPadding' => 'Medium Button Padding',
	'buttonPaddingLG' => 'Large Button Padding',

	'inputPadding' => 'Input Padding',
	'inputBackground' => 'Input Background',
	'inputBackgroundFocused' => 'Input Focused Background ',

	'cardPaddingSM' => 'Small Card Padding',
	'cardPadding' => 'Medium Card Padding',
	'cardPaddingLG' => 'Large Card Padding',

	'css' => 'CSS',

	'successfullyCreated' => 'Theme has been successfully created.',
	'successfullyEdited' => 'Theme has been successfully edited.',
	'successfullyEnabled' => 'Theme has been successfully enabled.',
	'successfullyDisabled' => 'Theme has been successfully disabled.',
	'successfullyDeleted' => 'Theme has been successfully deleted.',
	'successfullyImported' => 'The theme has been successfully imported.',

	'errorNew' => 'Please ensure that the name and author has 3-32 characters.',
	'errorDeleteEnabled' => 'Cannot delete the active theme.',
	'errorFileType' => 'The file type must be JSON.',
	'errorFileUpload' => 'Please upload a file, then submit.',

);