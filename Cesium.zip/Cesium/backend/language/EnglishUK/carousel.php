<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Carousel',

	'tittle' => 'Title',
	'description' => 'Description',
	'image' => 'Image Source',

	'settings' => 'Settings',
	'carouselSettings' => 'Carousel Settings',
	'settingsUpdated' => 'Settings have been successfully updated.',

	'enabled' => 'Enable Carousel',
	'pages' => 'Carousel Pages',
	'groups' => 'Carousel Groups',

	'empty' => 'No carousel items! Create one by clicking that "New" button.',

	'new' => 'New Carousel Item',
	'edit' => 'Edit Carousel Item',

	'successfullyCreated' => 'Carousel item has been successfully created.',
	'successfullyDeleted' => 'Carousel item has been successfully deleted.',
	'successfullyEdited' => 'Carousel item has been successfully edited.',

	'errorNew' => 'An error occured while creating carousel item.',
	'errorUpdate' => 'An error occured while updating carousel.',

);