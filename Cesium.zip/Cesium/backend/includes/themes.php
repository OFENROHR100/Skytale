<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Load the storage file
$csmDF->load('themes');

// Fetch all the announcements
$csmThemes = $csmDF->getAll();

// Find active theme
$csmActiveTheme = false;
foreach ($csmThemes as $key => $value) {
    if (!$csmActiveTheme && $value['enabled']) {
        $csmActiveTheme = $value;
    }
}

// Get active theme
$csmActiveTheme = $csmDF->load('themes/' . $csmActiveTheme['name'])->getAll();

// Generate the classes
$csmClasses = array();

if ($csmActiveTheme['borders']) {
	$csmClasses[] = 'hasBorders';
}

if ($csmActiveTheme['rounded']) {
	$csmClasses[] = 'hasRoundedCorners';
}

if ($csmActiveTheme['shadows']) {
	$csmClasses[] = 'hasBoxShadows';
}

if ($csmActiveTheme['avatars'] == 'rounded') {
	$csmClasses[] = 'hasRoundedAvatars';
} else if ($csmActiveTheme['avatars'] == 'circle') {
	$csmClasses[] = 'hasCircleAvatars';
}

// Assign the variables
$csmVars['classes'] = implode($csmClasses, ' ');