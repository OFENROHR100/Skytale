<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Load the storage file
$csmDF->load('general');

// Fetch all the general settings
$csmSettings = $csmDF->getAll();

// Fetch default general settings
$csmSettingsDefault = json_decode(file_get_contents($csmUtil->buildPath('/defaults/general.json')), true);;

// Generate the array
$arr = $csmSettingsDefault;
foreach ($csmSettings as $key => $value) {
	$arr[$key] = $value;
}

// Parse string function
function parseString($string) {
	$stringArray = array('{$SITE_NAME}', '{$SITE_URL}', '{$YEAR}');
	$replaceArray = array(($arr['siteTitle'] ? $arr['siteTitle'] : SITE_NAME), URL::build('/'), date('Y'));
	return nl2br(str_replace($stringArray, $replaceArray, $string));
}

// Parse the array values
foreach ($arr as $key => $value) {
	$arr[$key] = parseString($value);
}

// Generate discord server info
if ($arr['discordServer']) {
	$cache->setCache('social_media');
	$discordID = $cache->retrieve('discord');
	if ($discordID !== '') {
		if ($cache->isCached('discord_widget_check')) {
			$result = $cache->retrieve('discord_widget_check');
		} else {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			curl_setopt($ch, CURLOPT_URL, 'https://discordapp.com/api/servers/' . Output::getClean($discordID) . '/widget.json');
			$result = curl_exec($ch);
			$result = json_decode($result);
			curl_close($ch);
			$cache->store('discord_widget_check', $result, 60);
		}
		if (isset($result->channels)) {
			$arr['discord'] = array(
				'joinNow' => $csmLanguage->get('general', 'joinDiscord'),
				'members' => str_replace('{x}', $result->presence_count, $csmLanguage->get('general', 'membersOnline')),
				'link' => $result->instant_invite,
			);
		}
	}
}

// Generate mc server info
if ($arr['mcServer']) {
	$serverQuery = $smarty->getTemplateVars('SERVER_QUERY');
	$serverIP = $smarty->getTemplateVars('DEFAULT_IP');
	if ($serverQuery && $serverIP) {
		$arr['server'] = array(
			'ip' => $serverIP,
			'players' => str_replace('{x}', ($serverQuery['player_count'] ? $serverQuery['player_count'] : 0), $csmLanguage->get('general', 'playersOnline')),
		);
	}
}

// Extra variables
$arr['noNewsPosts'] = $csmLanguage->get('general', 'noNewsPosts');

// Assign the variables
$csmVars = array_merge($csmVars, $arr);