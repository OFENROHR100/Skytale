<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Load the storage file
$csmDF->load('carousel');

// Fetch all the announcements
$csmCarousel = $csmDF->getAll();

$arr = array();

if ($csmCarousel['enabled']) {

	if (in_array(PAGE, $csmCarousel['pages'])) {

		if ($user->isLoggedIn()) {

			if (in_array($user->data()->group_id, $csmCarousel['groups'])) {	

				$arr = $csmCarousel['items'];

			}	

		} else {

			if (in_array('guests', $csmCarousel['groups'])) {	

				$arr = $csmCarousel['items'];

			}

		}

	}

}

// Assign the variables
$csmVars['carousel'] = $arr;