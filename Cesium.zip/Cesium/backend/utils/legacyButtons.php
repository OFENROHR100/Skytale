<?php

/**
 *	NamelessMC ~ By Samerton
 *	https://github.com/samerton
 *
 *	Cesium Template ~ By Xemah
 *	https://xemah.com
 *
 *	Legacy Buttons [Util]
 */

$csmLegacyButtons = array(

	'permissions' => array(
		'title' => $csmLanguage->get('general', 'permissions'),
		'url' => URL::build('/panel/core/templates/', 'template=' . $_GET['template'] . '&action=permissions'),
		'icon' => '<i class="nav-icon fas fa-user-lock"></i>',
	),

	'back' => array(
		'title' => $csmLanguage->get('general', 'back'),
		'url' => URL::build('/panel/core/templates/'),
		'icon' => '<i class="nav-icon fas fa-arrow-alt-circle-left"></i>',
	),

);