<?php

/**
 *	NamelessMC ~ By Samerton
 *	https://github.com/samerton
 *
 *	Cesium Template ~ By Xemah
 *	https://xemah.com
 *
 *	Pages [Util]
 */

$csmPanelPages = array(

	'general' => array(
		'title' => $csmLanguage->get('general', 'settings'),
		'page' => '/pages/general/index.php',
		'icon' => '<i class="nav-icon fas fa-cog"></i>',
	),

	'announcements' => array(
		'title' => $csmLanguage->get('announcements', 'title'),
		'page' => '/pages/announcements/index.php',
		'icon' => '<i class="nav-icon fas fa-bullhorn"></i>',
	),

	'carousel' => array(
		'title' => $csmLanguage->get('carousel', 'title'),
		'page' => '/pages/carousel/index.php',
		'icon' => '<i class="nav-icon fas fa-images"></i>',
	),

	'themes' => array(
		'title' => $csmLanguage->get('themes', 'title'),
		'page' => '/pages/themes/index.php',
		'icon' => '<i class="nav-icon fas fa-paint-brush"></i>',
	),

	'misc' => array(
		'title' => $csmLanguage->get('general', 'misc'),
		'page' => '/pages/misc/index.php',
		'icon' => '<i class="nav-icon fas fa-sliders-h"></i>',
	),

	'update' => array(
		'title' => $csmLanguage->get('update', 'title'),
		'page' => '/pages/update/index.php',
		'icon' => '<i class="nav-icon fas fa-cloud-download-alt"></i>',
	),

);