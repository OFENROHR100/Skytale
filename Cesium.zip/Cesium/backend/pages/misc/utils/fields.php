<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmFields = array(

	'particles' => array(
		'label' => $csmLanguage->get('general', 'enableParticles'),
		'type' => 'checkbox',
		'name' => 'csmGeneralParticles',
		'id' => 'csmGeneralParticles',
	),

	'nestedReplies' => array(
		'label' => $csmLanguage->get('general', 'nestedReplies'),
		'type' => 'checkbox',
		'name' => 'csmGeneralNestedReplies',
		'id' => 'csmGeneralNestedReplies',
		'meta' => 'Show post replies without clicking replies button on profile page'
	),

	'developerMode' => array(
		'label' => $csmLanguage->get('general', 'developerMode'),
		'type' => 'checkbox',
		'name' => 'csmGeneralDeveloperMode',
		'id' => 'csmGeneralDeveloperMode',
	),

);