<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('carousel', 'edit');

// Generate breadcrumbs
$csmBreadcrumbs['edit'] = array(
	'name' => $csmLanguage->get('carousel', 'edit'),
	'link' => '',
);

// Get carousel fields
require_once('utils/fields.php');

// Load storage file
$csmDF->load('carousel');

// Get all carousel items
$csmCarousel = $csmDF->getAll();

// Check if id is defined and is valid
if (!isset($_GET['id']) || !$csmCarousel['items'][$_GET['id']]) {
	Redirect::to($csmUtil->buildPanelURL('/carousel'));
	die();
}

// Get the carousel item
$csmCarouselItem = $csmCarousel['items'][$_GET['id']];

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			foreach ($csmFields as $key => $value) {
				if (isset($_POST[$value['name']])) {
					if (is_array($_POST[$value['name']])) {
						$csmCarouselItem[$key] = $_POST[$value['name']];
					} else {
						$csmCarouselItem[$key] = Output::getClean($_POST[$value['name']]);
					}
				}
			}

			$csmCarousel = $csmDF->getAll();
			$csmCarousel['items'][$_GET['id']] = $csmCarouselItem;

			$csmDF->set($csmCarousel);
			$smarty->assign('CSM_SUCCESS', $csmLanguage->get('carousel', 'successfullyEdited'));

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('carousel', 'errorEdit'));
		}
		
	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}
}

// Assign the field values
foreach($csmFields as $key => $value) {
	$csmFields[$key]['value'] = $csmCarouselItem[$key];
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/carousel'),
));

// Assign smarty template
$csmTemplate = '/carousel/edit.tpl';