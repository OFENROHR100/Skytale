<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('general', 'settings');

// Get fields
require_once('utils/fields.php');

// Load the storage file
$csmDF->load('general');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			// Check if action is defined and is valid
			if (isset($_POST['action']) && array_key_exists($_POST['action'], $csmFields)) {

				$csmData = array();
				foreach ($csmFields[$_POST['action']]['fields'] as $key => $value) {
					$csmData[$key] = $_POST[$value['name']];
				}

				$csmDF->set($csmData);
				$smarty->assign('CSM_SUCCESS', $csmLanguage->get('general', 'settingsUpdated'));

			}
			
		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorEdit'));
		}
		
	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}

}

// Assign fields values
foreach ($csmFields as $key => $value) {
	foreach ($value['fields'] as $sKey => $sValue) {
		$csmFields[$key]['fields'][$sKey]['value'] = $csmDF->get($sKey);
	}
}

// Assign active tab pane
if (isset($_POST['action']) && array_key_exists($_POST['action'], $csmFields)) {
	$csmFields[$_POST['action']]['active'] = 1;
} else {
	foreach ($csmFields as $key => $value) {
		$csmFields[$key]['active'] = 1;
		break;
	}
}

// Assign session variables
if (Session::exists('CSM_SUCCESS')) {
	$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
}

if (Session::exists('CSM_ERROR')) {
	$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
));

// Assign smarty template
$csmTemplate = '/general/index.tpl';