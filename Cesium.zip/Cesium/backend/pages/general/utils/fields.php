<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmFields = array(

	'basic' => array(
		'name' => $csmLanguage->get('general', 'basic'),
		'id' => 'csmGeneralBasicSettings',
		'fields' => array(

			'siteTitle' => array(
				'label' => $csmLanguage->get('general', 'siteTitle'),
				'type' => 'text',
				'name' => 'csmGeneralSiteTitle',
				'id' => 'csmGeneralSiteTitle',
				'meta' => 'If empty, the default site name will be used.'
            ),

			'siteDescription' => array(
				'label' => $csmLanguage->get('general', 'siteDescription'),
				'type' => 'text',
				'name' => 'csmGeneralSiteDescription',
                'id' => 'csmGeneralSiteDescription',
            ),

			'siteImage' => array(
				'label' => $csmLanguage->get('general', 'siteImage'),
				'type' => 'text',
				'name' => 'csmGeneralSiteImage',
                'id' => 'csmGeneralSiteImage',
            ),

			'siteFavicon' => array(
				'label' => $csmLanguage->get('general', 'siteFavicon'),
				'type' => 'text',
				'name' => 'csmGeneralSiteFavicon',
                'id' => 'csmGeneralSiteFavicon',
            ),
			
		),
		
	),
	
	'header' => array(
		'name' => $csmLanguage->get('general', 'header'),
		'id' => 'csmGeneralHeaderSettings',
		'fields' => array(

			'header' => array(
				'label' => $csmLanguage->get('general', 'enableHeader'),
				'type' => 'checkbox',
				'name' => 'csmGeneralHeader',
                'id' => 'csmGeneralHeader',
            ),

			'logoAnimation' => array(
				'label' => $csmLanguage->get('general', 'enableLogoAnimation'),
				'type' => 'checkbox',
				'name' => 'csmLogoAnimation',
				'id' => 'csmLogoAnimation',
            ),

			'mcServer' => array(
				'label' => $csmLanguage->get('general', 'displayMCServer'),
				'type' => 'checkbox',
				'name' => 'csmGeneralMCServer',
				'id' => 'csmGeneralMCServer',
            ),

			'discordServer' => array(
				'label' => $csmLanguage->get('general', 'displayDiscordServer'),
				'type' => 'checkbox',
				'name' => 'csmGeneralDiscordServer',
				'id' => 'csmGeneralDiscordServer',
            ),

			'headerBackground' => array(
				'label' => $csmLanguage->get('general', 'headerBackground'),
				'type' => 'text',
				'name' => 'csmGeneralHeaderBackground',
                'id' => 'csmGeneralHeaderBackground',
                'meta' => 'If left empty, a solid background color will be used matching the theme.',
            ),

			'logoURL' => array(
				'label' => $csmLanguage->get('general', 'logoURL'),
				'type' => 'text',
				'name' => 'csmGeneralLogoURL',
				'id' => 'csmGeneralLogoURL',
                'meta' => 'If left empty, alternative text will be used in place of logo.',
            ),

			'logoAlt' => array(
				'label' => $csmLanguage->get('general', 'logoAlt'),
				'type' => 'text',
				'name' => 'csmGeneralLogoAlt',
                'id' => 'csmGeneralLogoAlt',
                'meta' => 'If logo url is empty, this text will be used as an alternative.'
            ),

        ),
        
	),

	'navbar' => array(
		'name' => $csmLanguage->get('general', 'navbar'),
		'id' => 'csmGeneralNavbarSettings',
		'fields' => array(
			
			'navbarStyle' => array(
				'label' => $csmLanguage->get('general', 'navbarStyle'),
				'type' => 'select',
				'name' => 'csmNavbarStyle',
				'id' => 'csmNavbarStyle',
				'options' => array(
					'auto' => array(
						'label' => $csmLanguage->get('general', 'navbarAuto'),
						'id' => 'auto',
						'value' => 'auto',
					),
					'full' => array(
						'label' => $csmLanguage->get('general', 'navbarFull'),
						'id' => 'full',
						'value' => 'full',
					),
					'sidebar' => array(
						'label' => $csmLanguage->get('general', 'navbarSidebar'),
						'id' => 'sidebar',
						'value' => 'sidebar',
					),
				),
			),
			
			'guestDropdown' => array(
				'label' => $csmLanguage->get('general', 'guestDropdown'),
				'type' => 'checkbox',
				'name' => 'csmGuestDropdown',
				'id' => 'csmGuestDropdown',
			),
			
			'panelInDropdown' => array(
				'label' => $csmLanguage->get('general', 'panelInDropdown'),
				'type' => 'checkbox',
				'name' => 'csmPanelInDropdown',
				'id' => 'csmPanelInDropdown',
			),

		),

	),

	'footer' => array(
		'name' => $csmLanguage->get('general', 'footer'),
		'id' => 'csmGeneralFooterSettings',
		'fields' => array(
			
			'footerContent' => array(
				'label' => $csmLanguage->get('general', 'footerContent'),
				'type' => 'textarea',
				'name' => 'csmFooterContent',
				'id' => 'csmFooterContent',
			),

		),

	),

);