<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if the id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('themes');

	// Check if theme exists
	if ($csmDF->_isset($_GET['id'])) {

		$csmTheme = $csmDF->get($_GET['id']);
		$csmExport = $csmDF->load('/themes/' . $csmTheme['name'])->getAll();
		
		header('Content-Description: Theme Export');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="' . $csmUtil->sanitizeString($csmExport['name']) . '.json"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		echo(json_encode($csmExport, JSON_PRETTY_PRINT));
		die();

	}

}