<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$validate = new Validate();

$validation = $validate->check($_POST, array(

	$csmNewFields['name']['name'] => array(
		'required' => true,
		'min' => 3,
		'max' => 32
	),

	$csmNewFields['author']['name'] => array(
		'required' => true,
		'min' => 3,
		'max' => 32
	),
	
));