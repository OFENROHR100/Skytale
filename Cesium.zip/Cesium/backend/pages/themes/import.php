<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle =  $csmLanguage->get('themes', 'import');

// Generate breadcrumbs
$csmBreadcrumbs['import'] = array(
	'name' => $csmLanguage->get('themes', 'edit'),
	'link' => '',
);

// Get theme import fields
require_once('utils/fieldsImport.php');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		$csmThemeFieldName = $csmImportFields['theme']['name'];
		$csmFile = $_FILES[$csmThemeFieldName];

		if ($csmFile['name'] !== '') {

			$csmThemesDirectory = $csmUtil->buildPath('/storage/themes/');
			$csmFileTempName = $csmFile['tmp_name'];
			$csmFileName = pathinfo($csmFile['name'], PATHINFO_FILENAME);
			$csmFileExtension = pathinfo($csmFile['name'], PATHINFO_EXTENSION);
			$csmFilePath = $csmThemesDirectory . $csmFileName . '.' . $csmFileExtension;

			if ($csmFileExtension == 'json') {

				$csmDefaultTheme = json_decode(file_get_contents($csmUtil->buildPath('/defaults/themes/default.json')), true);

				$importedTheme = json_decode(file_get_contents($csmFileTempName), true);
				foreach ($importedTheme as $key => $value) {
					$csmDefaultTheme[$key] = $value;
				}

				if (file_exists($csmFilePath)) {
					$i = 0;
					$csmFileNameOrigin = $csmFileName;
					while (file_exists($csmFilePath)) {
						$i++;
						$csmFileName = $csmFileNameOrigin . '_' . $i;
						$csmFilePath = $csmThemesDirectory . $csmFileName . '.' . $csmFileExtension;
					}
				}

				$csmNewTheme = array(
					'name' => $csmFileName,
					'enabled' => 0
				);
				
				$csmDF->create('themes/' . $csmNewTheme['name'])->set($csmDefaultTheme);
				$csmDF->load('themes')->set((int)max(array_keys($csmDF->getAll())) + 1, $csmNewTheme);

				Session::flash('CSM_SUCCESS', $csmLanguage->get('themes', 'successfullyImported'));
				Redirect::to($csmUtil->buildPanelURL('/themes'));

			} else {
				$smarty->assign('CSM_ERROR', $csmLanguage->get('themes', 'errorFileType'));
			}

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('themes', 'errorFileUpload'));
		}

	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}
}

// Assign Smarty variables
$smarty->assign(array(
	'CSM_IMPORT_FIELDS' => $csmImportFields,
	'CSM_IMPORT_THEME' => $csmLanguage->get('themes', 'import'),
	'CSM_IMPORT_ACTION' => $csmUtil->buildPanelURL('/themes', 'process=import'),
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/themes/'),
));

// Assign smarty template
$csmTemplate = '/themes/import.tpl';