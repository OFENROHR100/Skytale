<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('themes');

	// Get all the themes
	$csmThemes = $csmDF->getAll();

	foreach ($csmThemes as $key => $value) {
		if ($key == $_GET['id']) {
			$csmThemes[$key]['enabled'] = 1;
		} else {
			$csmThemes[$key]['enabled'] = 0;
		}
	}

	$csmDF->set($csmThemes);
	Session::flash('CSM_SUCCESS', $csmLanguage->get('themes', 'successfullyEnabled'));

}

// Redirect back to index page
Redirect::to($csmUtil->buildPanelURL('/themes'));
die();