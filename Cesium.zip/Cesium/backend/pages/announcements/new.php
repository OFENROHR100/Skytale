<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('announcements', 'new');

// Generate breadcrumbs
$csmBreadcrumbs['new'] = array(
	'name' => $csmLanguage->get('announcements', 'new'),
	'link' => '',
);

// Get announcement fields
require_once('utils/fields.php');

// Load the storage file
$csmDF->load('announcements');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			$csmData = array();
			foreach ($csmFields as $key => $value) {
				if (isset($_POST[$value['name']])) {
					if (is_array($_POST[$value['name']])) {
						$csmData[$key] = $_POST[$value['name']];
					} else {
						$csmData[$key] = Output::getClean($_POST[$value['name']]);
					}
				}
			}

			$csmData['enabled'] = 1;
			$csmDF->set((int)max(array_keys($csmDF->getAll())) + 1, $csmData);

			Session::flash('CSM_SUCCESS', $csmLanguage->get('announcements', 'successfullyCreated'));
			Redirect::to($csmUtil->buildPanelURL('/announcements'));

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('announcements', 'errorNew'));
		}

	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}

}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/announcements'),
));

// Assign smarty template
$csmTemplate = '/announcements/new.tpl';