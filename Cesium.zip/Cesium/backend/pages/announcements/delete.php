<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if the id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('announcements');

	// Check if annnouncement exists
	if ($csmDF->_isset($_GET['id'])) {
		$csmDF->_unset($_GET['id']);
		Session::flash('CSM_SUCCESS', $csmLanguage->get('announcements', 'successfullyDeleted'));
	}

}

// Redirect back to index page
Redirect::to($csmUtil->buildPanelURL('/announcements'));
die();