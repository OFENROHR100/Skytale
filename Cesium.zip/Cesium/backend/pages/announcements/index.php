<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Check if action is set
if (isset($_GET['process'])) {
	
	$csmActions = ['new', 'edit', 'toggle', 'delete'];
	if (in_array($_GET['process'], $csmActions)) {
		require_once($_GET['process'] . '.php');
		retrun;
	}

} else {

	// Assign page title
	$csmPageTitle = $csmLanguage->get('announcements', 'title');

	// Get announcement fields
	require_once('utils/fields.php');

	// Load the storage file
	$csmDF->load('announcements');

	// Get all the announcements
	$csmAnnouncements = $csmDF->getAll();

	// Generate announcements array
	foreach($csmAnnouncements as $key => $value) {
		$csmAnnouncements[$key]['actions'] = array(
			'toggle' => array(
				'text' => ($value['enabled'] ? $csmLanguage->get('general', 'disable') : $csmLanguage->get('general', 'enable')),
				'class' => ($value['enabled'] ? 'danger' : 'success'),
				'link' => $csmUtil->buildPanelURL('/announcements', 'process=toggle&id=' . $key),
			),
			'edit' => array(
				'text' => $csmLanguage->get('general', 'edit'),
				'class' => 'primary',
				'link' => $csmUtil->buildPanelURL('/announcements', 'process=edit&id=' . $key),
			),
			'delete' => array(
				'text' => $csmLanguage->get('general', 'delete'),
				'class' => 'secondary',
				'link' => $csmUtil->buildPanelURL('/announcements', 'process=delete&id=' . $key),
			),
		);
	}

	// Assign session variables
	if (Session::exists('CSM_SUCCESS')) {
		$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
	}

	if (Session::exists('CSM_ERROR')) {
		$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
	}

	// Assign smarty variables
	$smarty->assign(array(
		'CSM_FIELDS' => $csmFields,
		'CSM_ANNOUNCEMENTS' => $csmAnnouncements,
		'CSM_EMPTY_ANNOUNCEMENTS' => $csmLanguage->get('announcements', 'empty'),
		'CSM_NEW_ANNOUNCEMENT' => $csmLanguage->get('announcements', 'new'),
		'CSM_NEW_ACTION' => $csmUtil->buildPanelURL('/announcements', 'process=new'),
		'CSM_NEW' => $csmLanguage->get('general', 'new'),
		'CSM_TOGGLE' => $csmLanguage->get('general', 'toggle'),
		'CSM_ENABLE' => $csmLanguage->get('general', 'enable'),
		'CSM_DISABLE' => $csmLanguage->get('general', 'disable'),
		'CSM_EDIT' => $csmLanguage->get('general', 'edit'),
		'CSM_DELETE' => $csmLanguage->get('general', 'delete'),
	));

	// Assign smarty template
	$csmTemplate = '/announcements/index.tpl';

}