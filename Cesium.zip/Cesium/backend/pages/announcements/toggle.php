<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('announcements');

	// Get the announcement
	$csmAnnouncement = $csmDF->get($_GET['id']);

	// Toggle the announcement
	if($csmAnnouncement['enabled']) {
		$csmAnnouncement['enabled'] = 0;
		Session::flash('CSM_SUCCESS', $csmLanguage->get('announcements', 'successfullyDisabled'));
	} else {
		$csmAnnouncement['enabled'] = 1;
		Session::flash('CSM_SUCCESS', $csmLanguage->get('announcements', 'successfullyEnabled'));
	}
	
	// Update the file
	$csmDF->set($_GET['id'], $csmAnnouncement);
}

// Redirect back to index page
Redirect::to($csmUtil->buildPanelURL('/announcements'));
die();