<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmFields = array(

	'name' => array(
		'label' => $csmLanguage->get('announcements', 'name'),
		'type' => 'text',
		'name' => 'csmAnnouncementName',
		'id' => 'csmAnnouncementName',
	),

	'content' => array(
		'label' => $csmLanguage->get('announcements', 'content'),
		'type' => 'textarea',
		'name' => 'csmAnnouncementContent',
		'id' => 'csmAnnouncementContent',
	),

	'html' => array(
		'label' => $csmLanguage->get('announcements', 'html'),
		'type' => 'checkbox',
		'name' => 'csmAnnouncementHTML',
		'id' => 'csmAnnouncementHTML',
	),

	'type' => array (
		'label' => $csmLanguage->get('announcements', 'type'),
		'type' => 'radio',
		'name' => 'csmAnnouncementType',
		'id' => 'csmAnnouncementType',
		'options' => array()
	),

	'pages' => array(
		'label' => $csmLanguage->get('announcements', 'pages'),
		'type' => 'select',
		'name' => 'csmAnnouncementPages',
		'id' => 'csmAnnouncementPages',
		'listed' => 1,
		'options' => array()
	),

	'groups' => array(
		'label' => $csmLanguage->get('announcements', 'groups'),
		'type' => 'select',
		'name' => 'csmAnnouncementGroups',
		'id' => 'csmAnnouncementGroups',
		'listed' => 1,
		'options' => array()	
	),

);

$csmAnnouncementTypes = ['default', 'primary', 'success', 'danger', 'info', 'warning'];

foreach ($csmAnnouncementTypes as $item) {
	$csmFields['type']['options'][] = array(
		'label' => '<span class="badge badge-' . $item . '">' . $csmLanguage->get('announcements', 'type' . ucfirst($item)) . '</span>',
		'id' => $item,
		'value' => $item,
	);
}

$csmAnnouncementPages = array_filter($pages->returnPages(), function($p) {
	return $p['widgets'] == true;
});

foreach ($csmAnnouncementPages as $item) {
	$csmFields['pages']['options'][] = array(
		'label' => ucfirst($item['name']),
		'id' => ucfirst($item['name']),
		'value' => $item['name']
	);
}

$csmAnnouncementGroups = $queries->orderAll('groups', '`order`', 'ASC');

foreach($csmAnnouncementGroups as $item) {
	$csmFields['groups']['options'][] = array(
		'label' => $item->name,
		'id' => $item->id,
		'value' => $item->id
	);
}

$csmFields['groups']['options'][] = array(
	'label' => 'Guests',
	'id' => 'guests',
	'value' => 'guests'
);