<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$validate = new Validate();

$validation = $validate->check($_POST, array(

	$csmFields['name']['name'] => array(
		'required' => true,
		'min' => 3,
		'max' => 32
	),

	$csmFields['content']['name'] => array(
		'required' => true,
		'min' => 3
	),

	$csmFields['type']['name'] => array(
		'required' => true
	),
	
));